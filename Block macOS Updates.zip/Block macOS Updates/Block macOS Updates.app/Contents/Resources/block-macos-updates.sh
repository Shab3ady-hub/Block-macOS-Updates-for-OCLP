#!/bin/bash
# Blocks macOS updates and the upgrade banner (macOS 10.12 Sierra to 26 Tahoe; verified on Ventura only). See README.txt.
# Usage: sudo bash block-macos-updates.sh [options]
#   --aggressive    also disable the softwareupdated daemon
#   --keep-cache    do not move the cached update data
#   --status        only check that the block is still working (read-only), then exit
# Everything is backed up first; on any failure or Ctrl+C the changes are rolled back.
# Undo later: sudo bash /Library/macOS-Updates-Block-Backup/<date>/restore-update-settings.sh

AGGRESSIVE=0; CLEAR_CACHE=1; STATUS_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --aggressive) AGGRESSIVE=1 ;;
    --keep-cache) CLEAR_CACHE=0 ;;
    --status) STATUS_ONLY=1 ;;
    -h|--help) sed -n '2,8p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Unknown option: $arg (try --help)"; exit 1 ;;
  esac
done

# ---- Shared helpers (also copied into the generated restore script) ---------
init_colors() {
  if [ -t 1 ]; then
    C_R=$'\033[31m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_B=$'\033[1m'; C_D=$'\033[2m'; C_N=$'\033[0m'
  else
    C_R=""; C_G=""; C_Y=""; C_B=""; C_D=""; C_N=""
  fi
}
_log()    { [ -n "$LOG" ] && printf '%s  %s\n' "$(date '+%F %T')" "$*" >> "$LOG"; return 0; }
section() { printf '\n%s==> %s%s\n' "$C_B" "$*" "$C_N"; _log "== $*"; }
info()    { printf '         %s%s%s\n' "$C_D" "$*" "$C_N"; _log "$*"; }
ok()      { printf '  %s[ OK ]%s %s\n' "$C_G" "$C_N" "$*"; _log "OK: $*"; RES+=("OK|$*"); }
warn()    { printf '  %s[WARN]%s %s\n' "$C_Y" "$C_N" "$*"; _log "WARN: $*"; RES+=("WARN|$*"); }
fail()    { printf '  %s[FAIL]%s %s\n' "$C_R" "$C_N" "$*"; _log "FAIL: $*"; RES+=("FAIL|$*"); }
indent()  { printf '%s\n' "$1" | sed 's/^/         | /'; }
hint() {
  case "$1" in
    *"Operation not permitted"*) info "hint: give Terminal Full Disk Access (System Settings > Privacy & Security) and retry." ;;
    *"Permission denied"*)       info "hint: run with sudo." ;;
    *"Read-only file system"*)   info "hint: read-only volume (check the OCLP root-patch state)." ;;
  esac
}
# _exec fatal|attempt|soft "what this does" command...
#   fatal = on failure explain, roll back and stop; attempt = record FAIL and go on; soft = record WARN and go on
_exec() {
  local mode="$1" desc="$2" out rc; shift 2
  out="$("$@" 2>&1 < /dev/null)"; rc=$?
  _log "CMD: $* (exit $rc) $out"
  if [ $rc -eq 0 ]; then ok "$desc"; return 0; fi
  if [ "$mode" = soft ]; then warn "$desc (non-critical)"; else fail "$desc"; fi
  info "command: $* (exit $rc)"
  if [ -n "$out" ]; then indent "$out"; hint "$out"; fi
  [ "$mode" = fatal ] && abort "$desc"
  return $rc
}
run()     { _exec fatal "$@"; }
attempt() { _exec attempt "$@"; }
soft()    { _exec soft "$@"; }
daemon_disabled() {
  launchctl print-disabled system 2>/dev/null | grep 'com.apple.softwareupdated' | grep -Eq '=> (disabled|true)'
}
print_summary() {
  local e s
  N_OK=0; N_WARN=0; N_FAIL=0
  section "Summary"
  for e in "${RES[@]}"; do
    s="${e%%|*}"
    case "$s" in
      OK)   N_OK=$((N_OK+1)) ;;
      WARN) N_WARN=$((N_WARN+1)); printf '  %s[WARN]%s %s\n' "$C_Y" "$C_N" "${e#*|}" ;;
      FAIL) N_FAIL=$((N_FAIL+1)); printf '  %s[FAIL]%s %s\n' "$C_R" "$C_N" "${e#*|}" ;;
    esac
  done
  [ $((N_WARN+N_FAIL)) -eq 0 ] && echo "  No warnings or failures."
  printf '\n  %d passed, %d warnings, %d failed\n' "$N_OK" "$N_WARN" "$N_FAIL"
}

# ---- Rollback / abort -------------------------------------------------------
LOG=""; RES=(); BACKUP_READY=0; ROLLBACK_DONE=0; ROLLBACK_RC=-1; CACHE_MOVED=0
LEAK_FOUND=0

rollback() {
  [ "$ROLLBACK_DONE" = 1 ] && return 0
  ROLLBACK_DONE=1
  section "Rollback"
  if [ "$BACKUP_READY" != 1 ]; then ok "Nothing to roll back: nothing was changed yet"; ROLLBACK_RC=0; return 0; fi
  "$RESTORE" --auto; ROLLBACK_RC=$?
  if [ "$ROLLBACK_RC" -eq 0 ]; then ok "Rollback finished: everything is back as it was"
  else fail "Rollback had problems; run: sudo bash $RESTORE"; fi
}
abort() {
  printf '\n%s!! STOPPED: %s%s\n' "$C_R" "$1" "$C_N"; _log "ABORT: $1"
  rollback; print_summary; echo
  [ -n "$LOG" ] && echo "Log: $LOG"
  if [ "$ROLLBACK_RC" -eq 0 ]; then
    printf '%sRESULT: patch NOT applied; the Mac is back to its original state.%s\n' "$C_Y" "$C_N"; exit 1
  fi
  printf '%sRESULT: patch FAILED and the rollback had problems.%s\n' "$C_R" "$C_N"; exit 2
}
die() { fail "$1"; [ -n "${2:-}" ] && info "$2"; print_summary; printf '\n%sNothing was changed.%s\n' "$C_Y" "$C_N"; exit 1; }

# ---- Task helpers -----------------------------------------------------------
APPLE_HOSTS="swscan.apple.com swdist.apple.com gdmf.apple.com"
MARK_BEGIN="# BEGIN MACOS-UPDATES-BLOCK";      MARK_END="# END MACOS-UPDATES-BLOCK"
MARK6_BEGIN="# BEGIN MACOS-UPDATES-BLOCK-IPV6"; MARK6_END="# END MACOS-UPDATES-BLOCK-IPV6"
SU="/Library/Preferences/com.apple.SoftwareUpdate"

read_pref() { # domain key [user]
  if [ -n "${3:-}" ]; then sudo -u "$3" defaults read "$1" "$2" 2>/dev/null || echo "(not set)"
  else defaults read "$1" "$2" 2>/dev/null || echo "(not set)"; fi
}
verify_pref() { # description domain key expected [user]
  local got; got="$(read_pref "$2" "$3" "${5:-}")"
  if [ "$got" = "$4" ]; then ok "$1 (value $got)"; return 0; fi
  fail "$1"; info "expected: $4, found: $got"; abort "$1"
}
OS_IDS=("" Sierra HighSierra Mojave Catalina BigSur Monterey Ventura Sonoma Sequoia Tahoe)
OS_NAMES=("" "Sierra" "High Sierra" "Mojave" "Catalina" "Big Sur" "Monterey" "Ventura" "Sonoma" "Sequoia" "Tahoe")
os_rank() { # product version (10.14.6, 15.6.1, 26.0) -> 1..10 for Sierra..Tahoe, 0 if outside that range
  local a b; IFS=. read -r a b _ <<< "$1"
  case "$a" in
    10) case "$b" in 12) echo 1 ;; 13) echo 2 ;; 14) echo 3 ;; 15) echo 4 ;; *) echo 0 ;; esac ;;
    11) echo 5 ;; 12) echo 6 ;; 13) echo 7 ;; 14) echo 8 ;; 15) echo 9 ;; 26) echo 10 ;; *) echo 0 ;;
  esac
}
os_setup() { # sets VER, OS_RANK and NEWER (names of macOS releases newer than this one, as a regex; empty on Tahoe)
  local i; VER="$(sw_vers -productVersion 2>/dev/null)"; OS_RANK="$(os_rank "$VER")"; NEWER=""
  if [ "$OS_RANK" -gt 0 ]; then for ((i=OS_RANK+1; i<=10; i++)); do NEWER="$NEWER${NEWER:+|}${OS_IDS[$i]}"; done; fi
}
newer_data_files() { # cached update files that mention a NEWER macOS release (none on Tahoe or when the version is unknown)
  [ -n "$NEWER" ] || return 0
  grep -rlaiE "InstallAssistant[.A-Za-z0-9_]*($NEWER)" /Library/Updates /private/var/folders/*/*/C/softwareupdated /private/var/folders/*/*/T/softwareupdated 2>/dev/null | head -5
}
sched_state() { # on|off, from the preference (the wording printed by "softwareupdate --schedule" changes between macOS versions)
  case "$(read_pref "$SU" AutomaticCheckEnabled)" in
    0) echo off ;;
    1) echo on ;;
    *) case "$(softwareupdate --schedule 2>&1)" in *"turned off"*) echo off ;; *) echo on ;; esac ;;
  esac
}
clear_update_state() { # the "updates available" memory that the badge counts; only a successful check rebuilds it, and the block prevents that
  defaults delete "$SU" RecommendedUpdates 2>/dev/null
  defaults write "$SU" LastUpdatesAvailable -int 0 && defaults write "$SU" LastRecommendedUpdatesAvailable -int 0
}
restart_badge_owners() { # redraw the Dock / Settings badge and restart the update notifier (both run as the logged-in user)
  sudo -u "$TARGET_USER" killall Dock 2>/dev/null
  sudo -u "$TARGET_USER" killall SoftwareUpdateNotificationManager 2>/dev/null
  return 0
}
backup_file() { cp -p "$1" "$2" && cmp -s "$1" "$2"; }
hosts_newline() { if [ -s /etc/hosts ] && [ -n "$(tail -c1 /etc/hosts)" ]; then echo >> /etc/hosts; fi; }
add_hosts_block() {
  hosts_newline
  { echo "$MARK_BEGIN"; for d in $APPLE_HOSTS; do echo "0.0.0.0 $d"; done
    for d in $APPLE_HOSTS; do echo "::1 $d"; done; echo "$MARK_END"; } >> /etc/hosts
}
add_hosts_ipv6_block() { # only when an older IPv4-only block is already there
  hosts_newline
  { echo "$MARK6_BEGIN"; for d in $APPLE_HOSTS; do echo "::1 $d"; done; echo "$MARK6_END"; } >> /etc/hosts
}
reachable_hosts() { # prints the Apple hosts that can still be reached (empty = all blocked)
  local d code out=""
  for d in $APPLE_HOSTS; do
    code="$(curl -s -m 8 -o /dev/null -w '%{http_code}' "https://$d/" 2>/dev/null)"
    [ "$code" != "000" ] && out="$out $d(http $code)"
  done
  echo "$out"
}
collect_cache_items() { # cached update data that keeps the upgrade banner alive
  [ -e /Library/Updates/ProductMetadata.plist ] && echo /Library/Updates/ProductMetadata.plist
  find /private/var/folders -maxdepth 5 -type d -name com.apple.SoftwareUpdate.SUCatalogDataManager 2>/dev/null
  find /private/var/folders -maxdepth 5 -type f -name ProductMetadata.plist -path '*/softwareupdated/*' 2>/dev/null
  find /private/var/folders -maxdepth 5 -type f -name com.apple.SoftwareUpdate.SUUpdateServiceDaemon.state -path '*/softwareupdated/*' 2>/dev/null   # the update service's saved state (pending updates)
  return 0
}
move_cache_item() { # source index: move into the backup and record it for the restore script
  local dest="$BACKUP_DIR/cache/$2-$(basename "$1")"
  mkdir -p "$BACKUP_DIR/cache" && mv "$1" "$dest" && [ ! -e "$1" ] && [ -e "$dest" ] || return 1
  echo "$1|$dest" >> "$BACKUP_DIR/moved.list"
}

# Downloaded macOS updates ("staged"): update packages, the installer's working folder, and downloaded
# update assets. The cache move (step 4) already handles the update catalog data; this is the big stuff.
staged_items() {
  [ -d /Library/Updates ] && find /Library/Updates -mindepth 1 -maxdepth 1 ! -name ProductMetadata.plist 2>/dev/null
  [ -d "/macOS Install Data" ] && echo "/macOS Install Data"
  [ -d /System/Library/AssetsV2/com_apple_MobileAsset_MacSoftwareUpdate ] && find /System/Library/AssetsV2/com_apple_MobileAsset_MacSoftwareUpdate -mindepth 1 -maxdepth 1 -name '*.asset' 2>/dev/null
  return 0
}
delete_staged_updates() { # irreversible; never stops the run (it is the last step)
  local items item kb total=0 n=0 failed=""
  items="$(staged_items)"
  if [ -z "$items" ]; then ok "No downloaded macOS updates found on this Mac"; return 0; fi
  while IFS= read -r item; do
    [ -z "$item" ] && continue
    kb="$(du -sk "$item" 2>/dev/null | cut -f1)"; kb="${kb:-0}"
    rm -rf "$item" 2>/dev/null
    if [ -e "$item" ]; then failed="$failed$item"$'\n'
    else n=$((n+1)); total=$((total+kb)); _log "deleted $item (${kb} KB)"; fi
  done <<< "$items"
  [ "$n" -gt 0 ] && ok "Deleted $n downloaded update item(s), about $((total/1024)) MB (this cannot be undone)"
  if [ -n "$failed" ]; then warn "STAGED UPDATE NOT REMOVED: macOS would not let me delete these (System Integrity Protection?). Do not click Restart to update:"; indent "$failed"; fi
  return 0
}

restart_update_service() { # makes the update service re-read its (now cleared) state, so it forgets any update it thought was pending
  local out
  if out="$(launchctl kickstart -k system/com.apple.softwareupdated 2>&1)"; then ok "Restarted the macOS update service so it forgets any pending update"
  else info "Could not restart the update service now ($(printf '%s' "$out" | head -n1)). Restarting the Mac does the same."; fi
  return 0
}

write_state() {
  cat > "$BACKUP_DIR/state.env" <<STATE
TARGET_USER="$TARGET_USER"
USER_HOME="$USER_HOME"
SU_PLIST_EXISTED=$SU_PLIST_EXISTED
USER_PLIST_EXISTED=$USER_PLIST_EXISTED
SCHED_STATE="$SCHED_STATE"
DAEMON_WAS_DISABLED=$DAEMON_WAS_DISABLED
HOSTS_BLOCK_BEFORE=$HOSTS_BLOCK_BEFORE
HOSTS_IPV6_ADDED=0
DAEMON_CHANGED=0
STATE
}

# ---- Restore script generator ------------------------------------------------
generate_restore() {
  {
    echo '#!/bin/bash'
    echo "# Restores what block-macos-updates.sh changed on this Mac. Usage: sudo bash $RESTORE"
    declare -p BACKUP_DIR MARK_BEGIN MARK_END MARK6_BEGIN MARK6_END
    declare -f init_colors _log section info ok warn indent hint fail _exec attempt soft daemon_disabled print_summary
    cat <<'RESTORE_EOF'
LOG="$BACKUP_DIR/restore.log"; RES=(); init_colors
SU_PLIST="/Library/Preferences/com.apple.SoftwareUpdate.plist"

remove_hosts_blocks() {
  [ "$HOSTS_BLOCK_BEFORE" != 1 ] && sed -i '' "/^$MARK_BEGIN\$/,/^$MARK_END\$/d" /etc/hosts
  [ "$HOSTS_IPV6_ADDED" = 1 ] && sed -i '' "/^$MARK6_BEGIN\$/,/^$MARK6_END\$/d" /etc/hosts
  return 0
}
blocks_remaining() {
  { [ "$HOSTS_BLOCK_BEFORE" != 1 ] && grep -qx "$MARK_BEGIN" /etc/hosts; } && return 0
  { [ "$HOSTS_IPV6_ADDED" = 1 ] && grep -qx "$MARK6_BEGIN" /etc/hosts; } && return 0
  return 1
}
restore_hosts() { # remove only our blocks; if that fails, copy the full backup back
  remove_hosts_blocks 2>/dev/null
  if blocks_remaining; then cp -p "$BACKUP_DIR/hosts.bak" /etc/hosts || return 1; fi
  ! blocks_remaining
}
restore_plist() { # backup existed(0/1) target owner
  if [ "$2" = 1 ]; then cp -p "$1" "$3" && chown "$4" "$3" && cmp -s "$1" "$3"; else rm -f "$3" && [ ! -e "$3" ]; fi
}
restore_moved() { # original backup
  [ -e "$2" ] || { echo "backup copy missing: $2"; return 1; }
  mkdir -p "$(dirname "$1")" && rm -rf "$1" && mv "$2" "$1" && [ -e "$1" ]
}

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash $0"; exit 1; }
[ -f "$BACKUP_DIR/state.env" ] || { echo "Backup record not found in $BACKUP_DIR"; exit 2; }
. "$BACKUP_DIR/state.env"
USER_PLIST="$USER_HOME/Library/Preferences/com.apple.systempreferences.plist"
section "Restoring original settings from $BACKUP_DIR"

section "1/6 /etc/hosts"
NEED=0
{ [ "$HOSTS_BLOCK_BEFORE" != 1 ] && grep -qx "$MARK_BEGIN" /etc/hosts; } && NEED=1
{ [ "$HOSTS_IPV6_ADDED" = 1 ] && grep -qx "$MARK6_BEGIN" /etc/hosts; } && NEED=1
if [ "$NEED" = 1 ]; then
  if attempt "Remove the blocks added by the patch" restore_hosts; then
    if cmp -s /etc/hosts "$BACKUP_DIR/hosts.bak"; then ok "/etc/hosts is identical to the backup"
    else warn "/etc/hosts differs from the backup (normal if edited since)"; indent "$(diff "$BACKUP_DIR/hosts.bak" /etc/hosts 2>&1)"; fi
  fi
elif [ "$HOSTS_BLOCK_BEFORE" = 1 ]; then ok "The block was already there before the patch: left as it was"
else ok "No block in /etc/hosts: nothing to remove"; fi

section "2/6 Preferences"
killall cfprefsd 2>/dev/null
if [ "$SU_PLIST_EXISTED" = 1 ]; then attempt "Restore $SU_PLIST (verified)" restore_plist "$BACKUP_DIR/SoftwareUpdate.plist.bak" 1 "$SU_PLIST" root:wheel
else attempt "Remove $SU_PLIST (did not exist originally)" restore_plist "" 0 "$SU_PLIST" root:wheel; fi
if [ "$USER_PLIST_EXISTED" = 1 ]; then attempt "Restore $USER_PLIST (verified)" restore_plist "$BACKUP_DIR/systempreferences.plist.bak" 1 "$USER_PLIST" "$TARGET_USER"
else attempt "Remove $USER_PLIST (did not exist originally)" restore_plist "" 0 "$USER_PLIST" "$TARGET_USER"; fi
killall cfprefsd 2>/dev/null

section "3/6 Cached update data"
if [ -s "$BACKUP_DIR/moved.list" ]; then
  while IFS='|' read -r SRC DEST; do
    [ -n "$SRC" ] && attempt "Put back $SRC" restore_moved "$SRC" "$DEST"
  done < "$BACKUP_DIR/moved.list"
else ok "No cached data was moved: nothing to put back"; fi

section "4/6 Update schedule and daemon"
if attempt "Set automatic update checking back to: $SCHED_STATE" softwareupdate --schedule "$SCHED_STATE"; then
  WANT=1; [ "$SCHED_STATE" = off ] && WANT=0
  GOT="$(defaults read /Library/Preferences/com.apple.SoftwareUpdate AutomaticCheckEnabled 2>/dev/null)"
  if [ "$GOT" = "$WANT" ]; then ok "Verified: automatic checking is $SCHED_STATE"
  else warn "Could not confirm the schedule from the preference (found '$GOT'); the preferences file itself was restored and verified"; fi
fi
if [ "$DAEMON_CHANGED" = 1 ] && [ "$DAEMON_WAS_DISABLED" = 0 ]; then
  attempt "Re-enable softwareupdated" launchctl enable system/com.apple.softwareupdated
  if daemon_disabled; then fail "softwareupdated still reports as disabled"; else ok "Verified: softwareupdated is enabled"; fi
else ok "softwareupdated was not changed by the patch"; fi

section "5/6 Refresh"
soft "Flush DNS cache" dscacheutil -flushcache
soft "Reload mDNSResponder" killall -HUP mDNSResponder
soft "Restart Dock (refreshes the Settings badge)" killall Dock

print_summary; echo
if [ "$N_FAIL" -eq 0 ]; then
  touch "$BACKUP_DIR/RESTORED"
  printf '%sRESTORE COMPLETE: settings are back to how they were. Restart the Mac. Log: %s%s\n' "$C_G" "$LOG" "$C_N"; exit 0
fi
printf '%sRESTORE INCOMPLETE: %d item(s) failed (see [FAIL] above). Originals are in %s%s\n' "$C_R" "$N_FAIL" "$BACKUP_DIR" "$C_N"
echo "Manual fallback: delete the lines between '$MARK_BEGIN' and '$MARK_END' in /etc/hosts (and the IPV6 block),"
echo "run: sudo softwareupdate --schedule $SCHED_STATE; moved files are listed in $BACKUP_DIR/moved.list (original|backup)."
exit 1
RESTORE_EOF
  } > "$RESTORE" && chmod +x "$RESTORE"
}

# =============================================================================
# MAIN
# =============================================================================
[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo bash $0 [options]"; exit 1; }
init_colors; os_setup
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="/Library/macOS-Updates-Block-Backup/$(date +%Y%m%d-%H%M%S)"
while [ -e "$BACKUP_DIR" ]; do sleep 1; BACKUP_DIR="/Library/macOS-Updates-Block-Backup/$(date +%Y%m%d-%H%M%S)"; done   # never share a folder with an earlier run
RESTORE="$BACKUP_DIR/restore-update-settings.sh"
trap 'echo; abort "Interrupted (Ctrl+C)"' INT TERM

if [ "$STATUS_ONLY" = 1 ]; then
  printf '%sBlock status (read-only)%s\n' "$C_B" "$C_N"
  section "Is the block still working?"
  info "macOS $VER${OS_RANK:+ (${OS_NAMES[$OS_RANK]})}"
  FAILS=0
  for d in $APPLE_HOSTS; do
    if grep -q "^0.0.0.0 $d" /etc/hosts && grep -q "^::1 $d" /etc/hosts; then ok "/etc/hosts blocks $d (IPv4 + IPv6)"
    else fail "BLOCK MISSING: the /etc/hosts entries for $d are gone"; FAILS=$((FAILS+1)); fi
  done
  LEAKS="$(reachable_hosts)"
  if [ -z "$LEAKS" ]; then ok "The blocked Apple update servers cannot be reached"
  else fail "Apple update servers are still reachable:$LEAKS (VPN, proxy, custom DNS, or the hosts block is gone)"; FAILS=$((FAILS+1)); fi
  CHANGED=""
  for k in AutomaticCheckEnabled AutomaticDownload CriticalUpdateInstall; do [ "$(read_pref "$SU" "$k")" = 0 ] || CHANGED="$CHANGED $k"; done
  if [ -z "$CHANGED" ]; then ok "Automatic update checks and downloads are off"
  else fail "UPDATE SETTINGS CHANGED: back on or missing:$CHANGED"; FAILS=$((FAILS+1)); fi
  LEFT="$(newer_data_files)"
  if [ -n "$LEFT" ]; then fail "UPGRADE DATA PRESENT: cached update files mention a newer macOS again (this is what brings the upgrade banner back)"; indent "$LEFT"; FAILS=$((FAILS+1))
  elif [ -n "$NEWER" ]; then ok "No cached update data mentions a newer macOS"
  else info "This is the newest macOS release, so there is no newer-version data to look for"; fi
  STAGED="$(staged_items)"
  if [ -z "$STAGED" ]; then ok "No downloaded macOS update is staged on this Mac"
  else fail "STAGED UPDATE PRESENT: a downloaded macOS update is staged on this Mac (do not click Restart to update)"; indent "$STAGED"; FAILS=$((FAILS+1)); fi
  print_summary; echo
  if [ "$FAILS" -eq 0 ]; then printf '%sRESULT: block is intact.%s\n' "$C_G" "$C_N"; exit 0; fi
  printf '%sRESULT: block has %d problem(s).%s\n' "$C_Y" "$FAILS" "$C_N"; exit 4
fi

mkdir -p "$BACKUP_DIR" || { echo "Cannot create $BACKUP_DIR"; exit 1; }
LOG="$BACKUP_DIR/block-macos-updates.log"
printf '%smacOS update blocker%s   backup + log: %s\n' "$C_B" "$C_N" "$BACKUP_DIR"

# ---- Preflight ----------------------------------------------------------------
section "Preflight"
[ "$(uname)" = Darwin ] || die "This is not macOS"
if [ "$OS_RANK" -gt 0 ]; then ok "macOS $VER (${OS_NAMES[$OS_RANK]})"; else warn "macOS $VER is outside the supported range (Sierra 10.12 to Tahoe 26); continuing anyway"; fi
MISSING=""
for c in softwareupdate defaults launchctl dscl sed killall dscacheutil cmp curl find; do command -v "$c" >/dev/null 2>&1 || MISSING="$MISSING $c"; done
[ -n "$MISSING" ] && die "Required commands missing:$MISSING"
TARGET_USER="${SUDO_USER:-}"
{ [ -z "$TARGET_USER" ] || [ "$TARGET_USER" = root ]; } && TARGET_USER="$(stat -f%Su /dev/console 2>/dev/null)"
USER_HOME="$(dscl . -read "/Users/$TARGET_USER" NFSHomeDirectory 2>/dev/null | awk '{print $2}')"
{ [ -z "$TARGET_USER" ] || [ "$TARGET_USER" = root ] || [ ! -d "$USER_HOME" ]; } && die "Cannot find the logged-in user's home" "Run with sudo from your normal account, not a root shell."
[ -f /etc/hosts ] && [ -w /etc/hosts ] || die "/etc/hosts is missing or not writable"
ok "Required commands present, user $TARGET_USER, /etc/hosts writable"

# ---- Current state ------------------------------------------------------------
section "Current state"
if grep -qx "$MARK_BEGIN" /etc/hosts; then HOSTS_BLOCK_BEFORE=1; warn "The hosts block is already present (earlier run?); a restore keeps it"
else HOSTS_BLOCK_BEFORE=0; fi
grep -q '^::1 swscan.apple.com' /etc/hosts && HOSTS_V6_PRESENT=1 || HOSTS_V6_PRESENT=0
SCHED_STATE="$(sched_state)"
if daemon_disabled; then DAEMON_WAS_DISABLED=1; else DAEMON_WAS_DISABLED=0; fi
info "Hosts block: $HOSTS_BLOCK_BEFORE, IPv6 entries: $HOSTS_V6_PRESENT, automatic checking: $SCHED_STATE, daemon disabled: $DAEMON_WAS_DISABLED"

# ---- Backup and restore script ------------------------------------------------
section "Backup and safety net"
USER_PLIST="$USER_HOME/Library/Preferences/com.apple.systempreferences.plist"
run "Back up /etc/hosts (verified)" backup_file /etc/hosts "$BACKUP_DIR/hosts.bak"
SU_PLIST_EXISTED=0; USER_PLIST_EXISTED=0
if [ -f "$SU.plist" ]; then SU_PLIST_EXISTED=1; run "Back up Software Update preferences" backup_file "$SU.plist" "$BACKUP_DIR/SoftwareUpdate.plist.bak"; fi
if [ -f "$USER_PLIST" ]; then USER_PLIST_EXISTED=1; run "Back up $TARGET_USER's System Settings preferences" backup_file "$USER_PLIST" "$BACKUP_DIR/systempreferences.plist.bak"; fi
run "Save the original state" write_state
run "Generate the restore script" generate_restore
run "Syntax-check the restore script" bash -n "$RESTORE"
BACKUP_READY=1; ok "Automatic rollback is now active"

# ---- Apply --------------------------------------------------------------------
section "Step 1/4: turn off automatic checks and the Settings badge"
run "Turn off scheduled update checks" softwareupdate --schedule off
run "AutomaticCheckEnabled = false" defaults write "$SU" AutomaticCheckEnabled -bool false
run "AutomaticDownload = false" defaults write "$SU" AutomaticDownload -bool false
run "CriticalUpdateInstall = false" defaults write "$SU" CriticalUpdateInstall -bool false
soft "AutomaticallyInstallMacOSUpdates = false (where this macOS has it)" defaults write "$SU" AutomaticallyInstallMacOSUpdates -bool false
run "Clear the badge (user $TARGET_USER)" sudo -u "$TARGET_USER" defaults write com.apple.systempreferences AttentionPrefBundleIDs 0
soft "Forget the cached list of available updates (what the red badge counts)" clear_update_state
soft "Restart the Dock and the update notifier so the badge is redrawn" restart_badge_owners

section "Step 2/4: block Apple's update servers in /etc/hosts (IPv4 + IPv6)"
if [ "$HOSTS_BLOCK_BEFORE" = 1 ]; then
  ok "Block already present"
  if [ "$HOSTS_V6_PRESENT" = 1 ]; then ok "IPv6 entries already present"
  else run "Add the missing IPv6 (::1) entries" add_hosts_ipv6_block; sed -i '' 's/^HOSTS_IPV6_ADDED=0/HOSTS_IPV6_ADDED=1/' "$BACKUP_DIR/state.env"; fi
else
  run "Add swscan/swdist/gdmf.apple.com (0.0.0.0 and ::1) to /etc/hosts" add_hosts_block
fi
soft "Flush the DNS cache" dscacheutil -flushcache
soft "Reload mDNSResponder" killall -HUP mDNSResponder

section "Step 3/4: softwareupdated daemon"
if [ "$AGGRESSIVE" = 1 ]; then
  run "Disable softwareupdated" launchctl disable system/com.apple.softwareupdated
  sed -i '' 's/^DAEMON_CHANGED=0/DAEMON_CHANGED=1/' "$BACKUP_DIR/state.env"
else ok "Skipped (only with --aggressive)"; fi

section "Step 4/4: move the cached update data and the update service saved state into the backup"
if [ "$CLEAR_CACHE" = 0 ]; then ok "Skipped (--keep-cache)"
else
  LEAKS="$(reachable_hosts)"
  if [ -n "$LEAKS" ]; then
    LEAK_FOUND=1; warn "Apple servers are still reachable:$LEAKS. Moving the cache would be pointless (it would download again)."
    info "Look for a VPN, proxy or custom DNS, then run the script again. The other steps are applied."
  else
    ok "Apple servers are unreachable over IPv4 and IPv6: the cache cannot refill"
    ITEMS="$(collect_cache_items)"
    if [ -z "$ITEMS" ]; then ok "No cached update files found"
    else
      IDX=0
      while IFS= read -r ITEM; do
        [ -z "$ITEM" ] && continue
        IDX=$((IDX+1)); run "Move $ITEM to the backup" move_cache_item "$ITEM" "$IDX"; CACHE_MOVED=$((CACHE_MOVED+1))
      done <<< "$ITEMS"
    fi
  fi
fi

# ---- Verify -------------------------------------------------------------------
section "Verification"
for d in $APPLE_HOSTS; do
  if grep -q "^0.0.0.0 $d" /etc/hosts && grep -q "^::1 $d" /etc/hosts; then ok "/etc/hosts blocks $d (IPv4 + IPv6)"
  else fail "/etc/hosts entries missing for $d"; abort "Hosts entries missing for $d"; fi
done
LEAKS="$(reachable_hosts)"
if [ -z "$LEAKS" ]; then ok "Connection test: no Apple update server can be reached"
else LEAK_FOUND=1; warn "Connection test: still reachable:$LEAKS (VPN, proxy or custom DNS may bypass the block)"; fi
verify_pref "AutomaticCheckEnabled is off" "$SU" AutomaticCheckEnabled 0
verify_pref "AutomaticDownload is off" "$SU" AutomaticDownload 0
verify_pref "CriticalUpdateInstall is off" "$SU" CriticalUpdateInstall 0
verify_pref "Settings badge cleared" com.apple.systempreferences AttentionPrefBundleIDs 0 "$TARGET_USER"
info "softwareupdate --schedule says: $(softwareupdate --schedule 2>&1 | head -n1)"
if [ "$AGGRESSIVE" = 1 ]; then
  if daemon_disabled; then ok "softwareupdated is disabled"; else fail "softwareupdated is not disabled"; abort "Daemon not disabled"; fi
fi
if [ "$CACHE_MOVED" -gt 0 ]; then
  LEFT="$(newer_data_files)"
  if [ -z "$LEFT" ]; then ok "No cached update file mentions a newer macOS anymore"
  else warn "Some cached files still mention a newer macOS (rewritten by the update service?). Restart before opening System Settings."; indent "$LEFT"; fi
fi

# ---- Delete macOS updates that were already downloaded (last: it cannot be undone) ----
section "Final step: clear macOS updates that were already downloaded (cannot be undone)"
delete_staged_updates
restart_update_service

# ---- Done ---------------------------------------------------------------------
trap - INT TERM
print_summary; echo
if [ "$LEAK_FOUND" = 1 ]; then
  printf '%sRESULT: patch applied but NOT effective yet: Apple servers are still reachable (VPN, proxy or custom DNS?).%s\n' "$C_Y" "$C_N"
else
  printf '%sRESULT: patch applied and verified.%s\n' "$C_G" "$C_N"
fi
echo; echo "Next:"
[ "$LEAK_FOUND" = 1 ] && echo "  - Turn off the VPN / proxy / custom DNS, then run the block again."
echo "  - RESTART the Mac. Do NOT open System Settings before restarting."
echo "  - Then open General > Software Update: 'unable to check for updates / invalid URL' is normal (the block works)."
[ "$AGGRESSIVE" = 1 ] && echo "  - The restart is also needed for the daemon change."
echo "Undo: sudo bash $RESTORE"
echo "Log:  $LOG"
exit 0
